package com.gemblinggenk.banui;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class BanUIClient implements ClientModInitializer {

    private static KeyBinding openBanUiKey;

    @Override
    public void onInitializeClient() {
        // Default key: K
        openBanUiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.banui.open",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_K,
            "category.banui"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openBanUiKey.wasPressed()) {
                openBanScreen(client);
            }
        });

        // /banui still works as an alternative.
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(literal("banui")
                .executes(ctx -> {
                    openBanScreen(MinecraftClient.getInstance());
                    return Command.SINGLE_SUCCESS;
                }));

            dispatcher.register(literal("bui")
                .executes(ctx -> {
                    openBanScreen(MinecraftClient.getInstance());
                    return Command.SINGLE_SUCCESS;
                }));
        });
    }

    private static void openBanScreen(MinecraftClient client) {
        client.execute(() -> {
            if (client.currentScreen == null) {
                client.setScreen(new BanScreen());
            }
        });
    }
}
