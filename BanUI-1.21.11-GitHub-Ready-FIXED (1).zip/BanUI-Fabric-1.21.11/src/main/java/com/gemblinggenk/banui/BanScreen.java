package com.gemblinggenk.banui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class BanScreen extends Screen {
    private TextFieldWidget playerField, reasonField, durationField;

    private static final int RED = 0xFFE3262E;
    private static final int BG = 0xF20D0E11;
    private static final int PANEL = 0xF516171B;
    private static final int FIELD = 0xFF101115;
    private static final int BORDER = 0xFF3B3C42;
    private static final int WHITE = 0xFFF4F4F4;
    private static final int GREY = 0xFF9B9BA2;

    public BanScreen() { super(Text.literal("Ban Player")); }

    @Override
    protected void init() {
        int w = Math.min(700, width - 40);
        int x = (width - w) / 2;
        int y = Math.max(25, (height - 500) / 2);

        playerField = field(x + 28, y + 65, w - 56, 32, "Search IGN...");

        int bw = (w - 56 - 16) / 3;
        int by = y + 128;
        preset(x + 28, by, bw, "Hack Client", "14d");
        preset(x + 36 + bw, by, bw, "ESP", "7d");
        preset(x + 44 + bw * 2, by, bw, "Dodge", "3d");
        preset(x + 28, by + 38, bw, "Auto", "7d");
        preset(x + 36 + bw, by + 38, bw, "Illegal Mod", "7d");
        preset(x + 44 + bw * 2, by + 38, bw, "RMT", "Permanent");
        preset(x + 28, by + 76, bw, "Freehit", "1h");
        preset(x + 36 + bw, by + 76, bw, "Flood", "Permanent");
        preset(x + 44 + bw * 2, by + 76, bw, "Machine", "Permanent");

        reasonField = field(x + 28, y + 245, w - 56, 32, "Custom reason...");
        durationField = field(x + 28, y + 314, w - 56, 32, "7d / 1h / permanent");

        addDrawableChild(ButtonWidget.builder(Text.literal("BAN").formatted(Formatting.BOLD), b -> ban())
                .dimensions(x + 28, y + 375, w - 56, 38).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("BACK"), b -> close())
                .dimensions(x + 28, y + 422, w - 56, 28).build());
    }

    private TextFieldWidget field(int x, int y, int w, int h, String hint) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, x, y, w, h, Text.literal(hint));
        f.setPlaceholder(Text.literal(hint));
        f.setDrawsBackground(false);
        addDrawableChild(f);
        return f;
    }

    private void preset(int x, int y, int w, String reason, String duration) {
        addDrawableChild(ButtonWidget.builder(Text.literal(reason + "  •  " + duration), b -> {
            reasonField.setText(reason);
            durationField.setText(duration);
        }).dimensions(x, y, w, 30).build());
    }

    private void ban() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.player.networkHandler == null) return;
        String player = playerField.getText().trim();
        if (player.isEmpty()) return;
        String reason = reasonField.getText().trim();
        String duration = durationField.getText().trim();
        if (reason.isEmpty()) reason = "Banned by staff";
        String command = "ban " + player + " " + reason;
        if (!duration.isEmpty() && !duration.equalsIgnoreCase("permanent")) command += " | duration: " + duration;
        client.player.networkHandler.sendChatCommand(command);
        close();
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        renderBackground(c, mouseX, mouseY, delta);
        int w = Math.min(700, width - 40);
        int x = (width - w) / 2;
        int y = Math.max(25, (height - 500) / 2);

        // Screenshot-style black/red admin window.
        c.fill(0, 0, width, height, 0x88000000);
        c.fill(x - 5, y - 5, x + w + 5, y + 505, 0xFF050506);
        c.fill(x, y, x + w, y + 500, PANEL);
        c.fill(x, y, x + w, y + 4, RED);
        c.fill(x, y + 496, x + w, y + 500, RED);
        c.fill(x, y, x + 4, y + 500, RED);
        c.fill(x + w - 4, y, x + w, y + 500, RED);

        c.fill(x + 4, y + 4, x + w - 4, y + 50, 0xFF1C1D21);
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("BAN PLAYER").formatted(Formatting.BOLD), width / 2, y + 19, WHITE);

        label(c, "PLAYER", x + 28, y + 56);
        box(c, x + 28, y + 65, w - 56, 32);
        label(c, "PRESET REASONS", x + 28, y + 112);
        c.fill(x + 28, y + 119, x + w - 28, y + 120, BORDER);
        label(c, "BAN REASON", x + 28, y + 232);
        box(c, x + 28, y + 245, w - 56, 32);
        label(c, "DURATION", x + 28, y + 301);
        box(c, x + 28, y + 314, w - 56, 32);
        c.drawTextWithShadow(textRenderer, Text.literal("Press K to open  •  /banui also works"), x + 28, y + 466, GREY);

        super.render(c, mouseX, mouseY, delta);
    }

    private void label(DrawContext c, String s, int x, int y) { c.drawTextWithShadow(textRenderer, Text.literal(s), x, y, GREY); }
    private void box(DrawContext c, int x, int y, int w, int h) {
        c.fill(x, y, x + w, y + h, FIELD);
        c.fill(x, y, x + w, y + 1, BORDER);
        c.fill(x, y + h - 1, x + w, y + h, BORDER);
        c.fill(x, y, x + 1, y + h, BORDER);
        c.fill(x + w - 1, y, x + w, y + h, BORDER);
    }

    @Override public boolean shouldPause() { return false; }
}
