# Ban UI — Fabric 1.21.11

Target Minecraft Java **1.21.11**.

- Fabric Loader 0.18.1
- Fabric API 0.141.3+1.21.11
- Yarn 1.21.11+build.4
- Fabric Loom Remap 1.14
- Java 21

## Buka UI
- Tekan **K** (default keybind)
- Keybind dapat diganti di Options → Controls → Key Binds → Ban UI
- `/banui`
- `/bui`

## Ban
Tombol BAN mengirim:
`/ban <player> <reason>`

Vanilla `/ban` tidak mendukung durasi. Untuk server dengan LiteBans/AdvancedBan/LibertyBans, command tempban dapat disesuaikan di `BanScreen.java`.

## Build
Gunakan Java 21:

```bash
./gradlew build
```

Hasil:
`build/libs/banui-1.1.0.jar`

Catatan: 1.21.11 adalah rilis Minecraft terakhir yang menggunakan Yarn/Intermediary; Fabric merekomendasikan Loom 1.14 untuk 1.21.11. Untuk 26.1+, gunakan Mojang mappings/non-remap Loom.
